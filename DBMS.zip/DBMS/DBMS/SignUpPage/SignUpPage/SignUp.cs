﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SignUpPage
{
    public partial class SignUp : Form
    {
        int flagFirstName,flagLastName,flagAge,flagPhone,flagAdd,flagLicense,flagAadhar,flagUserName= 0;

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            flagPhone = 1;
        }

        private void textBox4_Click(object sender, EventArgs e)
        {
            if (flagPhone == 0)
                textBox4.ResetText();
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            flagAdd = 1;
        }

        private void textBox5_Click(object sender, EventArgs e)
        {
            if (flagAdd == 0)
                textBox5.ResetText();
        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {
            flagLicense = 1;
        }

        private void textBox6_Click(object sender, EventArgs e)
        {
            if (flagLicense == 0)
                textBox6.ResetText();
        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {
            flagAadhar = 1;
        }

        private void textBox7_Click(object sender, EventArgs e)
        {
            if (flagAadhar == 0)
                textBox7.ResetText();
        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {
            flagUserName = 1;
        }

        private void textBox8_Click(object sender, EventArgs e)
        {
            if (flagUserName == 0)
                textBox8.ResetText();
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            /*Number validation for the Age
             * This part of the code is for the number validation, which allows only numbers to be entered into the system*/
            if (!char.IsDigit(e.KeyChar))
                e.Handled = true;
            if (e.KeyChar == (char)8) //ASCII for backspace
                e.Handled = false;
        }

        private void textBox4_KeyPress(object sender, KeyPressEventArgs e)  //Phone Number
        {
            /*Number validation for entering phone number*/
            if (!char.IsDigit(e.KeyChar))
                e.Handled = true;
            if (e.KeyChar == (char)8) //ASCII for backspace
                e.Handled = false;
        }

        private void textBox7_KeyPress(object sender, KeyPressEventArgs e)  //Aadhar Number
        {
            /*Number validation for Aadhar Number*/
            if (!char.IsDigit(e.KeyChar))
                e.Handled = true;
            if (e.KeyChar == (char)8) //ASCII for backspace
                e.Handled = false;
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            /*First Name Validation code*/
            if (!char.IsLetter(e.KeyChar))
                e.Handled = true;

            if (e.KeyChar == (char)8)  //ASCII for backspace
                e.Handled = false;
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            /*Last Name Validation Code*/
            if (!char.IsLetter(e.KeyChar))
                e.Handled = true;

            if (e.KeyChar == (char)8)  //ASCII for backspace
                e.Handled = false;
        }

        private void textBox8_KeyPress(object sender, KeyPressEventArgs e)  //UserName
        {
            /*Username Validation Code*/
            if (!char.IsLetter(e.KeyChar))
                e.Handled = true;

            if (e.KeyChar == (char)8)  //ASCII for backspace
                e.Handled = false;
        }

        private void Form1_MouseClick(object sender, MouseEventArgs e)
        {

        }

        private void textBox3_Click(object sender, EventArgs e)
        {
            if (flagAge == 0)
                textBox3.ResetText();
            
        }

        public SignUp()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            flagFirstName = 1;
        }

        private void textBox1_Click(object sender, EventArgs e)
        {
            if(flagFirstName==0)
            textBox1.ResetText();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            flagLastName = 1;
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            flagAge = 1;
        }

        private void textBox2_Click(object sender, EventArgs e)
        {
            if (flagLastName == 0)
                textBox2.ResetText();
        }
    }
}
