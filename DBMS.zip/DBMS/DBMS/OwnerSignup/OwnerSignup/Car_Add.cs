﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OwnerSignup
{
    public partial class Car_Add : Form
    {
        int flagModel,flagRegNo,flagCarType,flagSeats,flagDistance = 0;
        public Car_Add()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            flagModel = 1;
        }

        private void textBox1_Click(object sender, EventArgs e)
        {
            if (flagModel == 0)
                textBox1.ResetText();
        }

        private void textBox2_Click(object sender, EventArgs e)
        {
            if (flagRegNo == 0)
                textBox2.ResetText();
        }

        private void textBox3_Click(object sender, EventArgs e)
        {
            if(flagCarType == 0)
            {
                textBox3.ResetText();
            }
        }

        private void textBox1_MouseLeave(object sender, EventArgs e)
        {
           //
        }

        private void textBox4_Click(object sender, EventArgs e)
        {
            if(flagSeats == 0)
            {
                textBox4.ResetText();
            }

        }

        private void textBox5_Click(object sender, EventArgs e)
        {
            if(flagDistance == 0)
            {
                textBox5.ResetText();
            }
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar))
                e.Handled = true;

            if (e.KeyChar == (char)8)  //ASCII for backspace
                e.Handled = false;
        }

        private void textBox4_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar))
                e.Handled = true;
            if (e.KeyChar == (char)8) //ASCII for backspace
                e.Handled = false;
        }

        private void textBox5_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar))
                e.Handled = true;
            if (e.KeyChar == (char)8) //ASCII for backspace
                e.Handled = false;
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            flagDistance = 1;
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            flagSeats = 1;
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            flagCarType = 1;
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            flagRegNo = 1;
        }
    }
}
