﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LoginScreen
{
    public partial class Form1 : Form
    {
        int flagText = 0,flagPass=0;        //Flag Text is a variable which checks whether text has been entered into the form or not
                                            //Flag Text is a variable which checks whether passwrod has been entered or not.
        public Form1()
        {
            InitializeComponent();
        }
        
        private void textBox1_MouseClick(object sender, MouseEventArgs e)
        {
            if(flagText==0)
                textBox1.ResetText();
        }

        private void textBox2_MouseClick(object sender, MouseEventArgs e)
        {
            if(flagPass==0)
            textBox2.ResetText();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            flagPass = 1;
        }

        private void label1_Click(object sender, EventArgs e)
        {
            label1.Hide();
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar))
                e.Handled = true;
           

            if (e.KeyChar == (char)8)  //ASCII for backspace
                e.Handled = false;

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            flagText = 1;
        }
    }
}
