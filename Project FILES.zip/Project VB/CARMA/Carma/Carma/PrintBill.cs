﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.ReportSource;
using System.Collections;
namespace Carma
{
    public partial class PrintBill : Form
    {
        public PrintBill()
        {
            InitializeComponent();
        }
        public String id;
        private void PrintBill_Load(object sender, EventArgs e)
        {
            try
            {

                SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\BCA\sem4\DBMS LAB\Project VB\CARMA\Carma\Carma\CarmaDB.mdf;Integrated Security=True");
                SqlCommand cmd = new SqlCommand("select * from billing_and_invoice where Invoice_Number= " + id, con);
                con.Open();
                cmd.ExecuteNonQuery();
                billdata ds = new billdata();
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds.Billing_And_Invoice);
                bill report = new bill();
                report.SetDataSource(ds);
                crystalReportViewer1.ReportSource = report;
                con.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show("" + ex);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
        }
    }
}
