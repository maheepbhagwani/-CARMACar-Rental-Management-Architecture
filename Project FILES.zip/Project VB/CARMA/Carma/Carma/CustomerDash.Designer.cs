﻿namespace Carma
{
    partial class CustomerDash
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CustomerDash));
            this.fromDate = new System.Windows.Forms.DateTimePicker();
            this.toDate = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.CarsAvailable = new System.Windows.Forms.ListBox();
            this.label3 = new System.Windows.Forms.Label();
            this.carPicker = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // fromDate
            // 
            this.fromDate.CalendarForeColor = System.Drawing.Color.Red;
            this.fromDate.Font = new System.Drawing.Font("Nexa Bold", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fromDate.Location = new System.Drawing.Point(167, 87);
            this.fromDate.Name = "fromDate";
            this.fromDate.Size = new System.Drawing.Size(306, 36);
            this.fromDate.TabIndex = 0;
            this.fromDate.ValueChanged += new System.EventHandler(this.fromDate_ValueChanged);
            // 
            // toDate
            // 
            this.toDate.CalendarForeColor = System.Drawing.Color.Red;
            this.toDate.Font = new System.Drawing.Font("Nexa Bold", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toDate.Location = new System.Drawing.Point(710, 87);
            this.toDate.Name = "toDate";
            this.toDate.Size = new System.Drawing.Size(297, 36);
            this.toDate.TabIndex = 1;
            this.toDate.Visible = false;
            this.toDate.ValueChanged += new System.EventHandler(this.toDate_ValueChanged);
            this.toDate.Leave += new System.EventHandler(this.toDate_Leave);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Nexa Bold", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Red;
            this.label2.Location = new System.Drawing.Point(74, 87);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(73, 30);
            this.label2.TabIndex = 3;
            this.label2.Text = "From";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Nexa Bold", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(635, 87);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 30);
            this.label1.TabIndex = 4;
            this.label1.Text = "To ";
            this.label1.Visible = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.Controls.Add(this.CarsAvailable);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.carPicker);
            this.panel1.Font = new System.Drawing.Font("Nexa Bold", 7.8F);
            this.panel1.Location = new System.Drawing.Point(79, 182);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1091, 479);
            this.panel1.TabIndex = 2;
            this.panel1.Visible = false;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // CarsAvailable
            // 
            this.CarsAvailable.BackColor = System.Drawing.Color.Black;
            this.CarsAvailable.Font = new System.Drawing.Font("Nexa Bold", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CarsAvailable.ForeColor = System.Drawing.Color.Red;
            this.CarsAvailable.FormattingEnabled = true;
            this.CarsAvailable.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.CarsAvailable.ItemHeight = 28;
            this.CarsAvailable.Location = new System.Drawing.Point(202, 86);
            this.CarsAvailable.Name = "CarsAvailable";
            this.CarsAvailable.Size = new System.Drawing.Size(678, 340);
            this.CarsAvailable.TabIndex = 6;
            this.CarsAvailable.Visible = false;
            this.CarsAvailable.SelectedIndexChanged += new System.EventHandler(this.CarsAvailable_SelectedIndexChanged);
            this.CarsAvailable.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.CarsAvailable_MouseDoubleClick);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Nexa Bold", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Red;
            this.label3.Location = new System.Drawing.Point(197, 32);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(150, 30);
            this.label3.TabIndex = 5;
            this.label3.Text = "Type Of Car";
            // 
            // carPicker
            // 
            this.carPicker.BackColor = System.Drawing.Color.Black;
            this.carPicker.Font = new System.Drawing.Font("Nexa Bold", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.carPicker.ForeColor = System.Drawing.Color.Red;
            this.carPicker.FormattingEnabled = true;
            this.carPicker.Location = new System.Drawing.Point(372, 33);
            this.carPicker.Name = "carPicker";
            this.carPicker.Size = new System.Drawing.Size(508, 29);
            this.carPicker.TabIndex = 0;
            this.carPicker.SelectedIndexChanged += new System.EventHandler(this.carPicker_SelectedIndexChanged);
            this.carPicker.Leave += new System.EventHandler(this.carPicker_Leave);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label4.Font = new System.Drawing.Font("Nexa Bold", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Red;
            this.label4.Location = new System.Drawing.Point(79, 28);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(296, 30);
            this.label4.TabIndex = 5;
            this.label4.Text = "Book Your Carma Today!";
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Black;
            this.button2.Font = new System.Drawing.Font("Nexa Bold", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.Red;
            this.button2.Location = new System.Drawing.Point(416, 21);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(139, 42);
            this.button2.TabIndex = 6;
            this.button2.Text = "Back";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // CustomerDash
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1262, 673);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.toDate);
            this.Controls.Add(this.fromDate);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.MaximumSize = new System.Drawing.Size(1280, 720);
            this.MinimumSize = new System.Drawing.Size(1280, 720);
            this.Name = "CustomerDash";
            this.Text = "Search For A Car";
            this.Load += new System.EventHandler(this.CustomerDash_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DateTimePicker fromDate;
        private System.Windows.Forms.DateTimePicker toDate;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox carPicker;
        private System.Windows.Forms.ListBox CarsAvailable;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button2;
    }
}