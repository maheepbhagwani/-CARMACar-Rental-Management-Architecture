﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.SqlClient;
namespace Carma
{
    public partial class Login : Form
    {
        int flagText = 0,flagPass=0;        //Flag Text is a variable which checks whether text has been entered into the form or not
                                  //Flag Text is a variable which checks whether passwrod has been entered or not.
        public Login()
        {
            InitializeComponent();
        }
        
        private void textBox1_MouseClick(object sender, MouseEventArgs e)
        {

        }

        private void textBox2_MouseClick(object sender, MouseEventArgs e)
        {
            if(flagPass==0)
            txtPassword.ResetText();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            flagPass = 1;
            
        }

        private void label1_Click(object sender, EventArgs e)
        {
            label1.Hide();
            txtPassword.Focus();
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar))
                e.Handled = true;
           

            if (e.KeyChar == (char)8)  //ASCII for backspace
                e.Handled = false;

        }

        private void Login_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            String str=" ",g=" ";
            if (flagText == 1 && flagPass == 1)
            {
                try
                {
                    SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\BCA\sem4\DBMS LAB\Project VB\CARMA\Carma\Carma\CarmaDB.mdf;Integrated Security=True");
                    SqlCommand com1 = new SqlCommand("select password,type,Adhaar_Number from customer where loginid='" + txtUsername.Text + "' union select password,type,Adhaar_Number from owner where login_id='" + txtUsername.Text + "'", con);
                    SqlCommand com2 = new SqlCommand("select First_name,gender from customer where loginid='" + txtUsername.Text + "';", con);
                    SqlCommand com3 = new SqlCommand("select gender from customer where loginid='" + txtUsername.Text + "';", con);
                    String pass = "";
                    con.Open();
                    String type="0",adhr="0";
                    SqlDataReader r = com1.ExecuteReader();
                    if (r.Read())
                    {
                       
                        pass = r.GetValue(0).ToString();
                        type = r.GetValue(1).ToString();
                        adhr = r.GetValue(2).ToString();
                    }
                    con.Close();
                    if (type.Equals("1"))
                    {
                        
                        MessageBox.Show("Logged In");
                        OwnerDash od = new OwnerDash();
                        od.adhaar= adhr;
                        od.Show();
                        this.Hide();
                    }
                    con.Open();
                    try
                    {
                        
                        SqlDataReader rs = com2.ExecuteReader();
                        rs.Read();
                        g = rs.GetValue(1).ToString();
                        if (g.Equals("M"))
                        {
                            str = " Mr. ";
                        }
                        else
                        {
                            str = " Ms. ";
                        }
                        
                    }
                    catch(Exception)
                    {
                        
                    }
                    con.Close();
                    con.Open();
                    try
                    {
                        if (pass.Equals(txtPassword.Text))
                        {
                           
                            SqlDataReader q = com2.ExecuteReader();
                            q.Read();
                            MessageBox.Show("Welcome " + str + q.GetValue(0).ToString());
                            if(type.Equals("0"))
                            {
                                CustomerLanding s = new CustomerLanding();
                                s.adh = adhr;
                                s.Show();
                                this.Hide();
                            }
                        }
                        else
                        {
                            var result = MessageBox.Show("Invalid Username - Password Combination!\nWant to Signup?", "Invalid Credentials", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
                            if (result == DialogResult.Yes)
                            {
                                new ownercustomer().Show();
                                this.Hide();
                            }
                            else if (result == DialogResult.No)
                            {
                                txtUsername.ResetText();
                                txtPassword.ResetText();

                            }
                        }
                        
                    }
                    catch (Exception)
                    {

                    }
                con.Close();

                }
                catch (Exception )
                {
                    var result = MessageBox.Show("Invalid Username - Password Combination!\nWant to Signup?", "Invalid Credentials", MessageBoxButtons.YesNoCancel,MessageBoxIcon.Question);
                    if (result == DialogResult.Yes)
                    {
                        new SignUp().Show();
                        this.Hide();
                    }
                    else if(result == DialogResult.No)
                    {
                        txtUsername.ResetText();
                        txtPassword.ResetText();
                    }
                    
                }
            }
            else
            {
                MessageBox.Show("Please Enter The Username & Password");
            }




            
            //customer directly goes to the dashboard
        }

        private void txtPassword_Enter(object sender, EventArgs e)
        {
            label1.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            new Decision().Show();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            flagText = 1;
        }
    }
}
