﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Carma
{
    public partial class CustomerLanding : Form
    {
        public String adh;
        public CustomerLanding()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            new Login().Show();
        }

        private void CustomerLanding_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\BCA\sem4\DBMS LAB\Project VB\CARMA\Carma\Carma\CarmaDB.mdf;Integrated Security=True");
            SqlCommand cmd = new SqlCommand("select First_Name,Last_Name from Customer where Adhaar_Number = '" + adh + "'", con);
            con.Open();
            String name = "";
            try
            {
                SqlDataReader rs = cmd.ExecuteReader();
                if (rs.Read())
                {
                    name = name + (rs.GetValue(0).ToString()) + " " + (rs.GetValue(1).ToString());

                }
                label1.Visible = true;
                label1.Text = "Welcome : " + name;
            }
            catch (Exception)
            {
            }
            con.Close();
        }

        private void add_CheckedChanged(object sender, EventArgs e)
        {
            this.Hide();
            CustomerDash c = new CustomerDash();
            c.adh = adh;
            c.Show();
        }

        private void view_CheckedChanged(object sender, EventArgs e)
        {
            Customerview c = new Customerview();
            c.cadhaar = adh;
            c.Show();
        }
    }
}
