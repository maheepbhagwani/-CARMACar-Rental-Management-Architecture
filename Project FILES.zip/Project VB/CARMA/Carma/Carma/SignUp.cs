﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.SqlClient;
namespace Carma
{
    public partial class SignUp : Form
    {
        int flagFirstName,flagLastName,flagAge,flagPhone,flagAdd,flagLicense,flagAadhar,flagUserName= 0;
        char g='F';
        public int typ;
        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            flagPhone = 1;
        }
        private void textBox4_Click(object sender, EventArgs e)
        {
            if (flagPhone == 0)
                txtPhone.ResetText();
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            flagAdd = 1;
        }

        private void textBox5_Click(object sender, EventArgs e)
        {
            if (flagAdd == 0)
                txtAddress.ResetText();
        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {
            flagLicense = 1;
        }

        private void textBox6_Click(object sender, EventArgs e)
        {
            if (flagLicense == 0)
                txtLicense.ResetText();
        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {
            flagAadhar = 1;
        }

        private void textBox7_Click(object sender, EventArgs e)
        {
            if (flagAadhar == 0)
                txtAdhaar.ResetText();
        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {
            flagUserName = 1;
        }

        private void textBox8_Click(object sender, EventArgs e)
        {
            if (flagUserName == 0)
                txtUsername.ResetText();
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            /*Number validation for the Age
             * This part of the code is for the number validation, which allows only numbers to be entered into the system*/
            if (!char.IsDigit(e.KeyChar))
                e.Handled = true;
            if (e.KeyChar == (char)8) //ASCII for backspace
                e.Handled = false;
        }

        private void textBox4_KeyPress(object sender, KeyPressEventArgs e)  //Phone Number
        {
            /*Number validation for entering phone number*/
            if (!char.IsDigit(e.KeyChar))
                e.Handled = true;
            if (e.KeyChar == (char)8) //ASCII for backspace
                e.Handled = false;
        }

        private void textBox7_KeyPress(object sender, KeyPressEventArgs e)  //Aadhar Number
        {
            /*Number validation for Aadhar Number*/
            if (!char.IsDigit(e.KeyChar))
                e.Handled = true;
            if (e.KeyChar == (char)8) //ASCII for backspace
                e.Handled = false;
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            /*First Name Validation code*/
            if (!char.IsLetter(e.KeyChar))
                e.Handled = true;

            if (e.KeyChar == (char)8)  //ASCII for backspace
                e.Handled = false;
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            /*Last Name Validation Code*/
            if (!char.IsLetter(e.KeyChar))
                e.Handled = true;

            if (e.KeyChar == (char)8)  //ASCII for backspace
                e.Handled = false;
        }

        private void textBox8_KeyPress(object sender, KeyPressEventArgs e)  //UserName
        {
            /*Username Validation Code*/
            if (!char.IsLetter(e.KeyChar))
                e.Handled = true;

            if (e.KeyChar == (char)8)  //ASCII for backspace
                e.Handled = false;
        }

        private void Form1_MouseClick(object sender, MouseEventArgs e)
        {

        }

        private void SignUp_Load(object sender, EventArgs e)
        {
            if(typ==1)
            {
                txtLicense.Enabled = false;
            }
        }

        private void btnSignUp_Click(object sender, EventArgs e)
        {
            
                try
                {
                    SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\BCA\sem4\DBMS LAB\Project VB\CARMA\Carma\Carma\CarmaDB.mdf;Integrated Security=True");
                    SqlCommand com1, com2;
                     int accno = 0;
                try
                {
                    Random bid = new Random();
                    accno = bid.Next(10000, 999999);
                    int r =0;
                    do
                    {

                        //accno = bid.Next(10000, 999999);
                        SqlConnection connct = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\BCA\sem4\DBMS LAB\Project VB\CARMA\Carma\Carma\CarmaDB.mdf;Integrated Security=True");
                        SqlCommand com3;
                        com3 = new SqlCommand("Select account_number from account", connct);
                        connct.Open();
                        SqlDataReader rs2 = com3.ExecuteReader();
                        while (rs2.Read())
                        {
                            String s = rs2.GetValue(0).ToString();
                            r = Convert.ToInt32(s);
                            if (r == accno)
                                break;
                        }
                        connct.Close();
                    } while (r == accno);
                }
                catch(Exception)
                {

                }
                con.Open();
                if (typ == 0)
                {
                    com1 = new SqlCommand("insert into Customer values ('" + txtLicense.Text + "','" + txtFname.Text + "','" + txtLname.Text + "', " + txtAge.Text + " ," + txtAdhaar.Text + ",'" + txtUsername.Text + "' ," + txtPhone.Text + " ,'" + txtAddress.Text + "' ,'" + g + "' , '" + txtPassword.Text + "'," + typ + " )", con);

                    com2 = new SqlCommand("insert into Account values (" + accno + ",'" + txtFname.Text + "','Customer', 50000," + txtAdhaar.Text + " )", con);
                }
                    
                else
                {
                    com1 = new SqlCommand("insert into Owner values (" + txtAdhaar.Text + ",'" + txtFname.Text + "','" + txtLname.Text + "','" + txtAddress.Text + "' ," + txtPhone.Text + " ,'" + txtUsername.Text + "' , '" + txtPassword.Text + "'," + typ + ")", con);
                    com2 = new SqlCommand("insert into Account values (" + accno + ",'" + txtFname.Text + "','Owner', 50000," + txtAdhaar.Text + " )", con);
                }

                        
                    
                    com1.ExecuteNonQuery();
                    com2.ExecuteNonQuery();
                    MessageBox.Show("Account Created!");
                    con.Close();
                    if (typ == 0)
                      {
                           this.Hide();
                           new Login().Show();
                      }

                    else
                    {
                        this.Hide();
                        Car_Add c = new Car_Add();
                        c.own = txtAdhaar.Text;
                        c.Show();
                    }

            }

                catch (Exception ex)
                {
                    MessageBox.Show("Username Already Taken! Please Try Again." +ex);
                    
                }


            
            

        }
        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            if(radioButton2.Checked==true)
            {

                radioButton2.Checked = false;
                radioButton1.Checked = true;
                

            }
            g = 'M';

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton1.Checked == true)
            {
                radioButton1.Checked = false;
                radioButton2.Checked = true;

            }
            g = 'F';
        }

        private void txtPassword_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void label2_Click(object sender, EventArgs e)
        {

            label2.Hide();
            txtPassword.Focus();
        }

        private void txtPassword_Enter(object sender, EventArgs e)
        {

            label2.Hide();
            txtPassword.Focus();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            new ownercustomer().Show();
        }

        private void textBox3_Click(object sender, EventArgs e)
        {
            if (flagAge == 0)
                txtAge.ResetText();
            
        }

        public SignUp()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            flagFirstName = 1;
        }

        private void textBox1_Click(object sender, EventArgs e)
        {
            if(flagFirstName==0)
            txtFname.ResetText();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            flagLastName = 1;
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            flagAge = 1;
        }

        private void textBox2_Click(object sender, EventArgs e)
        {
            if (flagLastName == 0)
                txtLname.ResetText();
        }
    }
}
