﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Carma
{
    public partial class Car_Add : Form
    {
        public String own;
        int flagModel,flagRegNo,flagCarType,flagSeats,flagDistance = 0;
        public Car_Add()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            flagModel = 1;
        }

        private void textBox1_Click(object sender, EventArgs e)
        {
            if (flagModel == 0)
                Model.ResetText();
        }

        private void textBox2_Click(object sender, EventArgs e)
        {
            if (flagRegNo == 0)
                Registration_Number.ResetText();
        }

        private void textBox3_Click(object sender, EventArgs e)
        {
            if(flagCarType == 0)
            {
                Car_Type.ResetText();
            }
        }

        private void textBox1_MouseLeave(object sender, EventArgs e)
        {
           //
        }

        private void textBox4_Click(object sender, EventArgs e)
        {
            if(flagSeats == 0)
            {
                Seating_Capacity.ResetText();
            }

        }

        private void textBox5_Click(object sender, EventArgs e)
        {
            if(flagDistance == 0)
            {
                Distance_Driven.ResetText();
            }
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar))
                e.Handled = true;

            if (e.KeyChar == (char)8)  //ASCII for backspace
                e.Handled = false;
        }

        private void textBox4_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar))
                e.Handled = true;
            if (e.KeyChar == (char)8) //ASCII for backspace
                e.Handled = false;
        }

        private void textBox5_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar))
                e.Handled = true;
            if (e.KeyChar == (char)8) //ASCII for backspace
                e.Handled = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if(Model.Text==""||Distance_Driven.Text == "" ||Seating_Capacity.Text == "" ||Distance_Driven.Text == "")
            {
                MessageBox.Show("Fields Cannot Be Left Blank.");
            }
            else
            {
                try
                {
                    SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\BCA\sem4\DBMS LAB\Project VB\CARMA\Carma\Carma\CarmaDB.mdf;Integrated Security=True");
                    SqlCommand com1;
                    com1 = new SqlCommand("insert into Car_Details values ('" + Registration_Number.Text + "'," + own + ",'" + Model.Text + "', " + Seating_Capacity.Text + " ,'" + Car_Type.SelectedItem + "'," + Distance_Driven.Text + ")", con);
                    con.Open();
                    com1.ExecuteNonQuery();
                    MessageBox.Show("Car Registered Successfully!");
                    this.Hide();
                    OwnerDash od = new OwnerDash();
                    od.adhaar = own;
                    od.Show();

                }

                catch (Exception)
                {
                    MessageBox.Show("Car Registration Failed. \nPlease Verify That All Fields Are Filled And Try Again.");

                }
            }
            

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            OwnerDash od = new OwnerDash();
            od.adhaar = own;
            od.Show();
        }

        private void Car_Add_Load(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            flagDistance = 1;
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            flagSeats = 1;
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            flagCarType = 1;
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            flagRegNo = 1;
        }
    }
}
