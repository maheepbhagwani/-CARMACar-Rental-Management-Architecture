﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Carma
{
    public partial class OwnerDash : Form
    {
        public String adhaar;
        public OwnerDash()
        {
            InitializeComponent();
        }

        private void OwnerDash_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\BCA\sem4\DBMS LAB\Project VB\CARMA\Carma\Carma\CarmaDB.mdf;Integrated Security=True");
            SqlCommand cmd = new SqlCommand("select First_Name,Last_Name from Owner where Adhaar_Number = '" + adhaar + "'", con);
            con.Open();
            String name="";
            try
            {
                SqlDataReader rs = cmd.ExecuteReader();
                if(rs.Read())
                {
                    name=name+(rs.GetValue(0).ToString())+" "+ (rs.GetValue(1).ToString());

                }
                label1.Text = "Welcome : " + name;
            }
            catch (Exception)
            {
            }
            con.Close();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            listBox.Items.Clear();
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\BCA\sem4\DBMS LAB\Project VB\CARMA\Carma\Carma\CarmaDB.mdf;Integrated Security=True");
            SqlCommand cmd = new SqlCommand("select Model from Car_Details where Adhaar_Number = '" + adhaar + "'", con);
            con.Open();
            try
            {
                SqlDataReader rs = cmd.ExecuteReader();

                while (rs.Read())
                {
                    listBox.Items.Add(rs.GetValue(0).ToString());
                }
            }
            catch (Exception)
            {
                // MessageBox.Show(ex+"");
            }
            con.Close();
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            listBox.Items.Clear();
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\BCA\sem4\DBMS LAB\Project VB\CARMA\Carma\Carma\CarmaDB.mdf;Integrated Security=True");
            SqlCommand cmd = new SqlCommand("select Model from Car_Details where Adhaar_Number = '" + adhaar + "'", con);
            con.Open();
            try
            {
                SqlDataReader rs = cmd.ExecuteReader();

                while (rs.Read())
                {
                    listBox.Items.Add(rs.GetValue(0).ToString());
                }
            }
            catch (Exception)
            {
                // MessageBox.Show(ex+"");
            }
            con.Close();
        }

        private void listBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void listBox_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if(view.Checked==true)
            {
                try
                {
                    SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\BCA\sem4\DBMS LAB\Project VB\CARMA\Carma\Carma\CarmaDB.mdf;Integrated Security=True");
                    SqlCommand cmd = new SqlCommand("select * from Car_Details where Adhaar_Number='" + adhaar + "' and model= '"+ listBox.SelectedItem + "'", con);
                    con.Open();
                    SqlDataReader rs = cmd.ExecuteReader();
                    if (rs.Read())
                    {
                        var result = MessageBox.Show("Registration Number: "+rs.GetValue(0)+ "\nModel: " + rs.GetValue(2)+ "\nSeating Capacity: " + rs.GetValue(3)+ "\nType: " + rs.GetValue(4)+ "\nOdometer Reading: " + rs.GetValue(5), "Car Details");
                    }
                    con.Close();
                }
                catch (Exception err)
                {
                    MessageBox.Show("Error." + err);

                }
                  }
            else if(delete.Checked==true)
            {
                var result = MessageBox.Show("Do You Wish To Remove "+listBox.SelectedItem+" ?", "Remove Car", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    string mod = listBox.GetItemText(listBox.SelectedItem);
                  
                    
                    SqlConnection connct = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\BCA\sem4\DBMS LAB\Project VB\CARMA\Carma\Carma\CarmaDB.mdf;Integrated Security=True");
                    SqlCommand com1;
                    com1 = new SqlCommand("delete from Car_Details where Model ='" +mod+ "' ", connct);
                    connct.Open();
                    com1.ExecuteNonQuery();
                    connct.Close();
                    listBox.Items.Clear();
                    SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\BCA\sem4\DBMS LAB\Project VB\CARMA\Carma\Carma\CarmaDB.mdf;Integrated Security=True");
                    SqlCommand cmd = new SqlCommand("select Model from Car_Details where Adhaar_Number = '" + adhaar + "'", con);
                    con.Open();
                    try
                    {
                        SqlDataReader rs = cmd.ExecuteReader();

                        while (rs.Read())
                        {
                            listBox.Items.Add(rs.GetValue(0).ToString());
                        }
                    }
                    catch (Exception)
                    {
                        // MessageBox.Show(ex+"");
                    }
                    con.Close();

                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            new Login().Show();
        }

        private void add_CheckedChanged(object sender, EventArgs e)
        {
            Car_Add c = new Car_Add();
            c.own = adhaar;
            this.Hide();
            c.Show();
        }

        private void radioButton1_CheckedChanged_1(object sender, EventArgs e)
        {

            CheckBookings cb = new CheckBookings();
            cb.adhaar = adhaar;

            if (radioButton1.Checked)
                cb.Show();
            //this.Hide();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {

        }
    }
}
