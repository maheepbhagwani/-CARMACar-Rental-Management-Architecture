﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.ReportSource;
using System.Collections;
namespace Carma
{
    public partial class Customerview : Form
    {
        public Customerview()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {

                SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\BCA\sem4\DBMS LAB\Project VB\CARMA\Carma\Carma\CarmaDB.mdf;Integrated Security=True");
                SqlCommand cmd = new SqlCommand("select * from billing_and_invoice where customer_adhaar= " + cadhaar, con);
                con.Open();
                cmd.ExecuteNonQuery();
                customerv1 ds = new customerv1();
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds.Billing_And_Invoice);
                CustomerView1 report = new CustomerView1();
                report.SetDataSource(ds);
                crystalReportViewer1.ReportSource = report;
                con.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show("" + ex);
            }
        }
        public String cadhaar;
        private void Customerview_Load(object sender, EventArgs e)
        {

        }
    }
}
