﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Carma
{
    public partial class CustomerDash : Form
    {
        int flag = 0;
        public String adh,reg;
        String type = "";
        public CustomerDash()
        {
            InitializeComponent();
        }
            private void toDate_Leave(object sender, EventArgs e)
        {
           
        }

        private void carPicker_SelectedIndexChanged(object sender, EventArgs e)
        {

            CarsAvailable.Items.Clear();
            String cartype = carPicker.SelectedItem.ToString();
            type = cartype;
            CarsAvailable.Visible = true;
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\BCA\sem4\DBMS LAB\Project VB\CARMA\Carma\Carma\CarmaDB.mdf;Integrated Security=True");
            SqlCommand cmd = new SqlCommand("select distinct(Model) from Car_Details where type= '"+cartype+"'", con);
            con.Open();
            try
            {
                SqlDataReader rs = cmd.ExecuteReader();
                
                while (rs.Read())
                {
                    CarsAvailable.Items.Add(rs.GetValue(0).ToString());
                }
            }
            catch (Exception )
            {
                
            }
            con.Close();
        }

        private void carPicker_Leave(object sender, EventArgs e)
        {
            
        }

        private void toDate_ValueChanged(object sender, EventArgs e)
        {
           
           // MessageBox.Show(dat);
            if(fromDate.Value.Date.DayOfYear >= toDate.Value.Date.DayOfYear)
            {
                MessageBox.Show("Invalid Booking Period.");
                panel1.Visible = false;
            }
            else
            if(flag==1)
            {
                panel1.Visible = true;

                carPicker.Items.Clear();
                SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\BCA\sem4\DBMS LAB\Project VB\CARMA\Carma\Carma\CarmaDB.mdf;Integrated Security=True");
                SqlCommand cmd = new SqlCommand("select distinct(Type) from Car_Details", con);
                con.Open();
                try
                {
                    SqlDataReader rs = cmd.ExecuteReader();
                    
                    while (rs.Read())
                    {
                        carPicker.Items.Add(rs.GetValue(0).ToString());
                    }
                }
                catch (Exception )
                {
                    // MessageBox.Show(ex+"");
                }
                con.Close();
            }
        }

        private void fromDate_ValueChanged(object sender, EventArgs e)
        {
            if(fromDate.Value.Date > DateTime.Today)
            {
                if (flag == 1)
                    if (fromDate.Value.Date.DayOfYear >= toDate.Value.Date.DayOfYear)
                    {
                        MessageBox.Show("Invalid Booking Period.");
                        panel1.Visible = false;
                    }
                    else
                        panel1.Visible = true;
                flag = 1;
                label1.Visible = true;
                toDate.Visible = true;
            }
            else
            {
                            fromDate.Value = DateTime.Today;
            }
            
        }

        private void CarsAvailable_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\BCA\sem4\DBMS LAB\Project VB\CARMA\Carma\Carma\CarmaDB.mdf;Integrated Security=True");
            SqlCommand cmd = new SqlCommand("select * from Car_Details where model='"+CarsAvailable.SelectedItem.ToString()+"'", con);
            con.Open();
            int day = toDate.Value.DayOfYear- fromDate.Value.DayOfYear;
            int r = 0, bookID=0;
            try
            {
                SqlDataReader rs = cmd.ExecuteReader();
                if(rs.Read())
                {
                    reg = rs.GetValue(0).ToString();
                    var result = MessageBox.Show("Seating Capacity: " + rs.GetValue(3) + "\nOdometer Reading: " + rs.GetValue(5)+ "\nBook Car For " + day+" Days?","Car Details", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
                    if (result == DialogResult.Yes)
                    {
                        try
                        {                            
                            do
                            {
                                Random bid = new Random();
                                bookID = bid.Next(0, 10000);
                                SqlConnection connct = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\BCA\sem4\DBMS LAB\Project VB\CARMA\Carma\Carma\CarmaDB.mdf;Integrated Security=True");
                                SqlCommand com1;
                                com1 = new SqlCommand("Select Booking_ID from Booking_Details", connct);
                                connct.Open();
                                SqlDataReader rs2 = com1.ExecuteReader();
                                while (rs2.Read())
                                {
                                    String s = rs2.GetValue(0).ToString();
                                    r = Convert.ToInt32(s);
                                    if (r == bookID)
                                        break;
                                }
                                connct.Close();
                            } while (r == bookID);
                        }
                        catch(Exception ex)
                        {
                            MessageBox.Show(ex+"");
                        }
                        try
                        {
                            SqlConnection connct = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\BCA\sem4\DBMS LAB\Project VB\CARMA\Carma\Carma\CarmaDB.mdf;Integrated Security=True");
                            SqlCommand com1;

                            com1 = new SqlCommand("insert into Booking_Details values (" + bookID + " ," + adh + " ,'" + reg + "', '" + DateTime.Now.Date.ToString("M/d/yyyy") + "' ,'" + fromDate.Value.ToString("M/d/yyyy") + "','" + toDate.Value.ToString("M/d/yyyy") + "' )", connct);
                            connct.Open();
                            com1.ExecuteNonQuery();
                            connct.Close();
                            MessageBox.Show("Booking Successful. Proceeding To Payment Portal.");
                            this.Hide();

                        }

                        catch (Exception err)
                        {
                            MessageBox.Show("Error."+ err);
                        }
                        Payment p = new Payment();
                        p.typ =type;
                        p.id = bookID.ToString();
                        p.days = day;
                        p.registration = reg;
                        p.adhaar = adh;
                        p.Show();

                    }
                    else if (result == DialogResult.No)
                    {
                    }
                }
            }
            catch (Exception)
            {
                
            }
            con.Close();
            
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void CustomerDash_Load(object sender, EventArgs e)
        {
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            CustomerLanding c = new CustomerLanding();
            c.adh = adh;
            c.Show();

        }

        private void CarsAvailable_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
