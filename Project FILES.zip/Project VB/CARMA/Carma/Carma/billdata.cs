﻿namespace Carma
{
}

namespace Carma
{


    public partial class billdata
    {
    }
}
namespace Carma {
    
    
    public partial class billdata {
    }
}
