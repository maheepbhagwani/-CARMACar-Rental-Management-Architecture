﻿namespace Carma
{
    partial class Car_Add
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Car_Add));
            this.Model = new System.Windows.Forms.TextBox();
            this.Registration_Number = new System.Windows.Forms.TextBox();
            this.Seating_Capacity = new System.Windows.Forms.TextBox();
            this.Distance_Driven = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.Car_Type = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // Model
            // 
            this.Model.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(22)))), ((int)(((byte)(22)))));
            this.Model.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Model.Font = new System.Drawing.Font("Nexa Bold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Model.ForeColor = System.Drawing.Color.White;
            this.Model.Location = new System.Drawing.Point(243, 234);
            this.Model.Multiline = true;
            this.Model.Name = "Model";
            this.Model.Size = new System.Drawing.Size(297, 27);
            this.Model.TabIndex = 0;
            this.Model.Text = "Model";
            this.Model.Click += new System.EventHandler(this.textBox1_Click);
            this.Model.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            this.Model.MouseLeave += new System.EventHandler(this.textBox1_MouseLeave);
            // 
            // Registration_Number
            // 
            this.Registration_Number.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(22)))), ((int)(((byte)(22)))));
            this.Registration_Number.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Registration_Number.Font = new System.Drawing.Font("Nexa Bold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Registration_Number.ForeColor = System.Drawing.Color.White;
            this.Registration_Number.Location = new System.Drawing.Point(243, 310);
            this.Registration_Number.Multiline = true;
            this.Registration_Number.Name = "Registration_Number";
            this.Registration_Number.Size = new System.Drawing.Size(297, 27);
            this.Registration_Number.TabIndex = 1;
            this.Registration_Number.Text = "Registration Number";
            this.Registration_Number.Click += new System.EventHandler(this.textBox2_Click);
            this.Registration_Number.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // Seating_Capacity
            // 
            this.Seating_Capacity.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(18)))), ((int)(((byte)(18)))));
            this.Seating_Capacity.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Seating_Capacity.Font = new System.Drawing.Font("Nexa Bold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Seating_Capacity.ForeColor = System.Drawing.Color.White;
            this.Seating_Capacity.Location = new System.Drawing.Point(726, 234);
            this.Seating_Capacity.MaxLength = 1;
            this.Seating_Capacity.Multiline = true;
            this.Seating_Capacity.Name = "Seating_Capacity";
            this.Seating_Capacity.Size = new System.Drawing.Size(297, 27);
            this.Seating_Capacity.TabIndex = 3;
            this.Seating_Capacity.Text = "Seating Capacity";
            this.Seating_Capacity.Click += new System.EventHandler(this.textBox4_Click);
            this.Seating_Capacity.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
            this.Seating_Capacity.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox4_KeyPress);
            // 
            // Distance_Driven
            // 
            this.Distance_Driven.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(18)))), ((int)(((byte)(18)))));
            this.Distance_Driven.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Distance_Driven.Font = new System.Drawing.Font("Nexa Bold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Distance_Driven.ForeColor = System.Drawing.Color.White;
            this.Distance_Driven.Location = new System.Drawing.Point(726, 310);
            this.Distance_Driven.MaxLength = 6;
            this.Distance_Driven.Multiline = true;
            this.Distance_Driven.Name = "Distance_Driven";
            this.Distance_Driven.Size = new System.Drawing.Size(297, 27);
            this.Distance_Driven.TabIndex = 4;
            this.Distance_Driven.Text = "Distance Driven (KMs)";
            this.Distance_Driven.Click += new System.EventHandler(this.textBox5_Click);
            this.Distance_Driven.TextChanged += new System.EventHandler(this.textBox5_TextChanged);
            this.Distance_Driven.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox5_KeyPress);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(18)))), ((int)(((byte)(18)))));
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Nexa Bold", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.button1.Location = new System.Drawing.Point(380, 517);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(221, 43);
            this.button1.TabIndex = 5;
            this.button1.Text = "Skip";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(18)))), ((int)(((byte)(18)))));
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Nexa Bold", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.button2.Location = new System.Drawing.Point(659, 517);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(221, 43);
            this.button2.TabIndex = 6;
            this.button2.Text = "Register Car";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Car_Type
            // 
            this.Car_Type.BackColor = System.Drawing.Color.Black;
            this.Car_Type.Font = new System.Drawing.Font("Nexa Bold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Car_Type.ForeColor = System.Drawing.SystemColors.Window;
            this.Car_Type.FormattingEnabled = true;
            this.Car_Type.Items.AddRange(new object[] {
            "Sedan",
            "Hatchback",
            "SUV",
            "Crossover",
            "Sports",
            "Others"});
            this.Car_Type.Location = new System.Drawing.Point(243, 371);
            this.Car_Type.Name = "Car_Type";
            this.Car_Type.Size = new System.Drawing.Size(297, 33);
            this.Car_Type.TabIndex = 7;
            this.Car_Type.Text = " Type";
            this.Car_Type.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // Car_Add
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkRed;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1262, 673);
            this.Controls.Add(this.Car_Type);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.Distance_Driven);
            this.Controls.Add(this.Seating_Capacity);
            this.Controls.Add(this.Registration_Number);
            this.Controls.Add(this.Model);
            this.MaximumSize = new System.Drawing.Size(1280, 720);
            this.MinimumSize = new System.Drawing.Size(1280, 720);
            this.Name = "Car_Add";
            this.Text = "List A Car";
            this.Load += new System.EventHandler(this.Car_Add_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox Model;
        private System.Windows.Forms.TextBox Registration_Number;
        private System.Windows.Forms.TextBox Seating_Capacity;
        private System.Windows.Forms.TextBox Distance_Driven;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.ComboBox Car_Type;
    }
}

