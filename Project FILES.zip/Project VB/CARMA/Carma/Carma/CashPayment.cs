﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Carma
{
    public partial class CashPayment : Form
    {
        public String id, type, adhaar, registration;

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            new Login().Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            PrintBill p = new PrintBill();
            p.id = id;
            p.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
                CustomerLanding cl = new CustomerLanding();
                cl.adh = adhaar;
                cl.Show();
                this.Hide();
            
        }

        private void button4_Click(object sender, EventArgs e)
        {
          
        }

        private void DisplayLabel_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        public int days;
        public CashPayment()
        {
            InitializeComponent();
        }

        private void CashPayment_Load(object sender, EventArgs e)
        {

            String current = DateTime.Now.Date.ToString("M/d/yyyy");
               
            int price;
            if (type.Equals("Sedan"))
            {
                price = days * 1000;
            }
            else if (type.Equals("Hatchback"))
            {
                price = days * 600;
            }
            else if (type.Equals("SUV"))
            {
                price = days * 1500;
            }
            else if (type.Equals("Crossover"))
            {
                price = days * 800;
            }
            else if (type.Equals("Sports"))
            {
                price = days * 2000;
            }
            else
            {
                price = days * 500;
            }
            DisplayLabel.Visible = true;
            DisplayLabel.Text = "Congratulations, You Have Successfully \nBooked A Car For "+days+" Days\nThe Booking ID Is: "+id+ "\nThe Amount To Be Paid Is: " + price + " \nPlease Pay The Amount While Picking Up The Car.";
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\BCA\sem4\DBMS LAB\Project VB\CARMA\Carma\Carma\CarmaDB.mdf;Integrated Security=True");
            SqlCommand cmd = new SqlCommand("insert into Billing_And_Invoice values (" + id + " ," + adhaar + " ,'"+current+"','" +registration+ "'," + days + "," + price + " ,'Cash')", con);
            con.Open();
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception eeee)
            {
                MessageBox.Show(eeee+"");
            }
            con.Close();

        }
    }
}
