﻿namespace Carma
{
    partial class Payment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Payment));
            this.Cash = new System.Windows.Forms.Button();
            this.Card = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Cash
            // 
            this.Cash.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(22)))), ((int)(((byte)(22)))));
            this.Cash.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Cash.Font = new System.Drawing.Font("Nexa Bold", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Cash.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(203)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.Cash.Location = new System.Drawing.Point(375, 313);
            this.Cash.Name = "Cash";
            this.Cash.Size = new System.Drawing.Size(221, 43);
            this.Cash.TabIndex = 0;
            this.Cash.Text = "Cash";
            this.Cash.UseVisualStyleBackColor = false;
            this.Cash.Click += new System.EventHandler(this.button1_Click);
            // 
            // Card
            // 
            this.Card.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(22)))), ((int)(((byte)(22)))));
            this.Card.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Card.Font = new System.Drawing.Font("Nexa Bold", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Card.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(203)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.Card.Location = new System.Drawing.Point(670, 313);
            this.Card.Name = "Card";
            this.Card.Size = new System.Drawing.Size(221, 43);
            this.Card.TabIndex = 1;
            this.Card.Text = "Card";
            this.Card.UseVisualStyleBackColor = false;
            this.Card.Click += new System.EventHandler(this.button2_Click);
            // 
            // Payment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1262, 673);
            this.Controls.Add(this.Card);
            this.Controls.Add(this.Cash);
            this.MaximumSize = new System.Drawing.Size(1280, 720);
            this.MinimumSize = new System.Drawing.Size(1280, 720);
            this.Name = "Payment";
            this.Load += new System.EventHandler(this.Payment_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button Cash;
        private System.Windows.Forms.Button Card;
    }
}

