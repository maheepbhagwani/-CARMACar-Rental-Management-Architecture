﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Carma
{
    public partial class Payment : Form
    {
        public String typ, id, adhaar, registration;
        public int days;
        CashPayment c = new CashPayment();
        CardPayment cd = new CardPayment();
        public Payment()
        {
            InitializeComponent();
        }

        private void Payment_Load(object sender, EventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            c.type = typ;
            c.id = id;
            c.days = days;
            c.adhaar = adhaar;
            c.registration = registration;
            c.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            cd.type = typ;
            cd.id = id;
            cd.days = days;

            cd.cadhaar = adhaar;
            cd.registration = registration;
            cd.Show();
        }
    }
}
