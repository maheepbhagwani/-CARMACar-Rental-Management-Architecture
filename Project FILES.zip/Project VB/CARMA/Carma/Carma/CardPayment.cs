﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.ReportSource;
using System.Collections;
namespace Carma
{
    public partial class CardPayment : Form
    {
        public String type, id, cadhaar, registration, oadhaar;
        public Boolean flag = false;
        

        private void Pay_Click(object sender, EventArgs e)
        {
         
            if (CardNumber.Text.Equals("")|| CVV.Text.Equals("") || ExpirationDate.Text.Equals(""))
            {
                if (CardNumber.Text.Equals("") )
                {
                    CardNumber.Focus();
                    ErrorLab.Visible = true;
                    ErrorLab.Text = "Please Enter A Card Number.";
                    button4.Visible = true;
                }
                else if(ExpirationDate.Text.Equals(""))
                {
                    ExpirationDate.Focus();
                    ErrorLab.Visible = true;
                    ErrorLab.Text = "Please Enter Expiration Date. ";
                    button4.Visible = true;
                }
                else
                {
                    CVV.Focus();
                    ErrorLab.Visible = true;
                    ErrorLab.Text = "Please Enter CVV.";
                    button4.Visible = true;
                }


            }
            else
            {
                flag = true;
                String current = DateTime.Now.Date.ToString("M/d/yyyy");

                int price;
                if (type.Equals("Sedan"))
                {
                    price = days * 1000;
                }
                else if (type.Equals("Hatchback"))
                {
                    price = days * 600;
                }
                else if (type.Equals("SUV"))
                {
                    price = days * 1500;
                }
                else if (type.Equals("Crossover"))
                {
                    price = days * 800;
                }
                else if (type.Equals("Sports"))
                {
                    price = days * 2000;
                }
                else
                {
                    price = days * 500;
                }


                SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\BCA\sem4\DBMS LAB\Project VB\CARMA\Carma\Carma\CarmaDB.mdf;Integrated Security=True");
                SqlCommand cmd = new SqlCommand("insert into Billing_And_Invoice values (" + id + " ," + cadhaar + " ,'" + current + "','" + registration + "'," + days + "," + price + " ,'Card')", con);
                SqlCommand customerupdate = new SqlCommand("update Account set Balance = Balance - "+price+" where Adhaar = "+cadhaar, con);
                SqlCommand ownerupdate = new SqlCommand("update account set balance=balance+"+price+" where Adhaar = "+oadhaar, con);
                con.Open();
                try
                {
                    cmd.ExecuteNonQuery();
                    customerupdate.ExecuteNonQuery();
                    ownerupdate.ExecuteNonQuery();
                    MessageBox.Show("Payment Processed Sucessfully!");
                    panel1.Visible = false;
                    
                }
                catch (Exception eeee)
                {
                    MessageBox.Show(eeee + "");
                }
                con.Close();
            }
            

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(flag==false)
            {
                ErrorLab.Text = "Cannot Logout Before Completing Payment."; //Check this 
            }

            else
            {
                var result = MessageBox.Show("Do You Want To Login Again?", "Login / Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    this.Hide();
                    new Login().Show();

                }
                else if (result == DialogResult.No)
                {
                    Application.Exit();
                }
            }
            
            
        }

        private void ExpirationDate_Enter(object sender, EventArgs e)
        {
            ExpirationDate.ResetText();
        }

        private void CardNumber_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar))
                e.Handled = true;

            if (e.KeyChar == (char)8)  //ASCII for backspace
                e.Handled = false;
        }

        private void ExpirationDate_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar))
                e.Handled = true;

            if (e.KeyChar == (char)8)  //ASCII for backspace
                e.Handled = false;
        }

        private void CVV_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar))
                e.Handled = true;

            if (e.KeyChar == (char)8)  //ASCII for backspace
                e.Handled = false;
        }

        private void Clear_Click(object sender, EventArgs e)
        {
            CardNumber.ResetText();
            CVV.ResetText();
            ExpirationDate.ResetText();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
            

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            PrintBill p = new PrintBill();
            p.id = id;
            p.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            CustomerLanding cl = new CustomerLanding();
            cl.adh = cadhaar;
            cl.Show();
            this.Hide();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            CashPayment c = new CashPayment();
            c.adhaar = cadhaar;
            c.type = type;
            c.id = id;
            c.days = days;
            c.registration = registration;
            c.Show();
            this.Hide();
        }

        public int days;
        public CardPayment()
        {
            InitializeComponent();
        }

        private void CardPayment_Load(object sender, EventArgs e)
        {
            oadhaar = " ";
            try
            {
                SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\BCA\sem4\DBMS LAB\Project VB\CARMA\Carma\Carma\CarmaDB.mdf;Integrated Security=True");
                SqlCommand cmd = new SqlCommand("select adhaar_number from car_details where registration_Number='" + registration + "'", con);
                con.Open();
                SqlDataReader rs = cmd.ExecuteReader();
                if (rs.Read())
                {
                    oadhaar = rs.GetValue(0).ToString();
                }
            }
            catch (Exception)
            {

            }
        }
    }
}
