﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Carma
{
    
    public partial class ownercustomer : Form
    {
        SignUp s = new SignUp();
       
        public ownercustomer()
        {
            InitializeComponent();
        }

        private void ownercustomer_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            new Decision().Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            s.typ = 0;
            this.Hide();
            s.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            s.typ = 1;
            this.Hide();
            s.Show();
        }
    }
}
